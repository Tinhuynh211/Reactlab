import { Component } from "react";

class Hello extends Component{
    render(){
        return <h1>This is Heading</h1>     
    }
}
export default Hello;